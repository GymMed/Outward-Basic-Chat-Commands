## Changelog

### Release 0.0.2 Version

#### Added

-   Added <code>setVisuals</code> command,
-   Added multiple <code>enchantments</code> commands,
-   Added multiple <code>time</code> commands,
-   Added <code>skills</code> command,
-   Added <code>maxChatMessages</code> command.

#### Fixed

-   Changed code structure.

### Release 0.0.1 Version

-   Initial release.
